-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 23, 2019 at 10:24 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `edureka`
--

-- --------------------------------------------------------

--
-- Table structure for table `vendors`
--

CREATE TABLE `vendors` (
  `id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pdf_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pdf_link1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `instruction` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `terms_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `term_content` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `vendors`
--

INSERT INTO `vendors` (`id`, `title`, `image_url`, `pdf_link`, `pdf_link1`, `instruction`, `description`, `terms_title`, `term_content`) VALUES
(1, 'Aerobie', 'Aerobie-2019-Brochure.png', 'http://eurekatoyandgift.com/2019/SW Aerobie 2019 Brochure 08282018.pdf', '', 'Once open in new tab please press “Ctrl+s” to save catalog.', NULL, NULL, NULL),
(2, 'BC Mini', 'BCmini.png', 'http://eurekatoyandgift.com/2018/2018 BCmini.pdf', 'http://eurekatoyandgift.com/2018/2018 BCmini.pdf', 'Once open in new tab please press “Ctrl+s” to save catalog.', NULL, '2018 Standard Terms', '$100 Minimum order; $300=FFA; Backorders under $100 canceled if not able to ship within 2 weeks; CC on 1st order - Visa-MC-AE- To Discover;**signed cr app required for all accounts*.'),
(3, 'Be Amazing', 'Be-Amazing.png', 'http://eurekatoyandgift.com/2018/2018 Be Amazing newProduct-Announcement-Flyer.pdf', 'http://eurekatoyandgift.com/2018/2018 Be Amazing Toys Catalog Small.pdf', 'Once open in new tab please press “Ctrl+s” to save catalog.', 'Be Amazing – Putting the fun in science and educational toys! It is the goal of Be Amazing to provide quality toys at a reasonable price while giving our end consumer an exciting learning experience. Incorporating the Science of Steve Spangler, made famous with his appearances on The Ellen DeGeneres Show, and exciting new products of Blue Sky Airplanes, SICK! Science Kits and many more wonderful products, Be Amazing is a must have line for your store.\r\n\r\n', '2018 Standard Terms', 'NO FBA - NO AE - $300 Min Opening Order & $250 reorder; $750=FFA & N60; $500=1/2FFA & N30'),
(4, 'Bigjigs Toys', 'logo2.png', 'http://eurekatoyandgift.com/2018/BIGJIGS TOYS 2018 Catalogue - Low res.pdf', 'http://eurekatoyandgift.com/2018/Bigjigs Toys New 2018 products with prices.pdf', 'Once open in new tab please press “Ctrl+s” to save catalog.', NULL, '2018 Standard Terms', '$200 Minimum Order; $500=N60 & 1/2 FFA; $750=N90 & FFA; CsPk not required - no AE'),
(5, 'Brictek', 'Brictek_logo.png', 'http://eurekatoyandgift.com/2018/Brictek-2018-Catalogue.pdf', '', 'Once open in new tab please press “Ctrl+s” to save catalog.', NULL, '2018 Standard Terms', 'Min $250; $500=8% freight flat rate;\r\n$1000=5% freight flat rate; $1500=FFA; Visa, MC & AE'),
(6, 'Capstone Edelweiss', 'default.png', 'http://eurekatoyandgift.com/2018/Capstone Edelweiss-New Titles Spring 2018 Collection.pdf', '', 'Once open in new tab please press “Ctrl+s” to save catalog.', NULL, NULL, NULL),
(7, 'Continuum Game', 'Continuum-Game.png', 'http://eurekatoyandgift.com/2018/CG_FullLineCatalog_2018-19_lo-res.pdf', '', 'Once open in new tab please press “Ctrl+s” to save catalog.', NULL, '2018 Standard Terms', 'STEM - No minimum order-no case pack requirements; Freight Saver-order $350 of Freight Saver items & receive FFA on entire\r\norder; any order of $1,000+=FFA; IMPORTANT:BACKORDERS ON FFA ORDERS WILL SHIP 1/2 FFA-Otherwise Mark NO\r\nBACKORDERS'),
(8, 'Creative Toy Company', 'CTC-2018-Catalog-Email1.png', 'http://eurekatoyandgift.com/2018/CTC 2018 Catalog Email.pdf', 'http://eurekatoyandgift.com/2017/Creative_ToyNew Product Summer 2017.pdf', 'Once open in new tab please press “Ctrl+s” to save catalog.', NULL, '2018 Standard Terms', 'STEM - $100 minimum payable by cc - puzzles can be ordered in asst 6\'s; $500=1/2 FFA & N30,$1200=FFA & N60'),
(9, 'Fridolin', 'FTTH-Fridolin-2018-Katalog.png', 'http://eurekatoyandgift.com/2018/FTTH Fridolin 2018 Katalog.pdf', 'http://eurekatoyandgift.com/2017/FTTH Wupper April 2017 Sell Sheet.pdf', 'Once open in new tab please press “Ctrl+s” to save catalog.', NULL, NULL, NULL),
(10, 'Funsparks', '2018-Funsparks-Catalog.png', 'http://eurekatoyandgift.com/2017/Funsparks 2017 Full Catalog.pdf', '', 'Once open in new tab please press “Ctrl+s” to save catalog.', NULL, NULL, NULL),
(11, 'Geomag World USA', '2018-Geomag-Catalog.png', 'http://eurekatoyandgift.com/2018/2018 Geomag Catalog.pdf', '', 'Once open in new tab please press “Ctrl+s” to save catalog.', NULL, '2018 Standard Terms', 'NO FBA - STEM - $250 min opening order & $150 min reorder; $750=N60/FFA & $1000=N90FFA'),
(12, 'Hart Toy', 'Hart-Toys-Logo-3.jpg', 'Once open in new tab please press “Ctrl+s” to save catalog.', '', 'Once open in new tab please press “Ctrl+s” to save catalog.', NULL, NULL, NULL),
(13, 'LEGO BAGS', 'Lego-logo.png', 'http://eurekatoyandgift.com/2018/LEGO Bags 2018 Catalog.pdf', '', 'Once open in new tab please press “Ctrl+s” to save catalog.', NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `vendors`
--
ALTER TABLE `vendors`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `vendors`
--
ALTER TABLE `vendors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
